﻿namespace WindowsFormsApplication7
{
    partial class BTunbutrProject1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.costLabel = new System.Windows.Forms.Label();
            this.quantityLabel = new System.Windows.Forms.Label();
            this.costTextBox = new System.Windows.Forms.RichTextBox();
            this.quantityTextBox = new System.Windows.Forms.RichTextBox();
            this.orderInfoGroupBox = new System.Windows.Forms.GroupBox();
            this.partNumberTextBox = new System.Windows.Forms.RichTextBox();
            this.partNumberLabel = new System.Windows.Forms.Label();
            this.expressRadioButton = new System.Windows.Forms.RadioButton();
            this.groundRadioButton = new System.Windows.Forms.RadioButton();
            this.shippingGroupBox = new System.Windows.Forms.GroupBox();
            this.paymentTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.moneyOrderRadioButton = new System.Windows.Forms.RadioButton();
            this.codRadioButton = new System.Windows.Forms.RadioButton();
            this.chargeRadioButton = new System.Windows.Forms.RadioButton();
            this.newCustomerCheckBox = new System.Windows.Forms.CheckBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.orderSummaryGroupBox = new System.Windows.Forms.GroupBox();
            this.newCustomerLabel = new System.Windows.Forms.Label();
            this.partTextBox = new System.Windows.Forms.RichTextBox();
            this.partLabel = new System.Windows.Forms.Label();
            this.paymentTextBox = new System.Windows.Forms.RichTextBox();
            this.paymentTypeLabel = new System.Windows.Forms.Label();
            this.shippingTextBox = new System.Windows.Forms.RichTextBox();
            this.totalCostTextBox = new System.Windows.Forms.RichTextBox();
            this.shippingtypeLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.orderInfoGroupBox.SuspendLayout();
            this.shippingGroupBox.SuspendLayout();
            this.paymentTypeGroupBox.SuspendLayout();
            this.orderSummaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApplication7.Properties.Resources.shipping2;
            this.pictureBox1.Location = new System.Drawing.Point(29, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(114, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // costLabel
            // 
            this.costLabel.AutoSize = true;
            this.costLabel.Location = new System.Drawing.Point(16, 31);
            this.costLabel.Name = "costLabel";
            this.costLabel.Size = new System.Drawing.Size(28, 13);
            this.costLabel.TabIndex = 1;
            this.costLabel.Text = "Cost";
            this.costLabel.Click += new System.EventHandler(this.costLabel_Click);
            // 
            // quantityLabel
            // 
            this.quantityLabel.AutoSize = true;
            this.quantityLabel.Location = new System.Drawing.Point(16, 62);
            this.quantityLabel.Name = "quantityLabel";
            this.quantityLabel.Size = new System.Drawing.Size(46, 13);
            this.quantityLabel.TabIndex = 2;
            this.quantityLabel.Text = "Quantity";
            this.quantityLabel.Click += new System.EventHandler(this.quantityLabel_Click);
            // 
            // costTextBox
            // 
            this.costTextBox.Location = new System.Drawing.Point(95, 28);
            this.costTextBox.Name = "costTextBox";
            this.costTextBox.Size = new System.Drawing.Size(100, 25);
            this.costTextBox.TabIndex = 3;
            this.costTextBox.Text = "";
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.Location = new System.Drawing.Point(95, 59);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(100, 25);
            this.quantityTextBox.TabIndex = 4;
            this.quantityTextBox.Text = "";
            // 
            // orderInfoGroupBox
            // 
            this.orderInfoGroupBox.Controls.Add(this.partNumberTextBox);
            this.orderInfoGroupBox.Controls.Add(this.partNumberLabel);
            this.orderInfoGroupBox.Controls.Add(this.quantityTextBox);
            this.orderInfoGroupBox.Controls.Add(this.costTextBox);
            this.orderInfoGroupBox.Controls.Add(this.quantityLabel);
            this.orderInfoGroupBox.Controls.Add(this.costLabel);
            this.orderInfoGroupBox.Location = new System.Drawing.Point(175, 10);
            this.orderInfoGroupBox.Name = "orderInfoGroupBox";
            this.orderInfoGroupBox.Size = new System.Drawing.Size(217, 130);
            this.orderInfoGroupBox.TabIndex = 5;
            this.orderInfoGroupBox.TabStop = false;
            this.orderInfoGroupBox.Text = "&Order Information";
            this.toolTip1.SetToolTip(this.orderInfoGroupBox, "Enter mail order information here");
            // 
            // partNumberTextBox
            // 
            this.partNumberTextBox.Location = new System.Drawing.Point(95, 90);
            this.partNumberTextBox.Name = "partNumberTextBox";
            this.partNumberTextBox.Size = new System.Drawing.Size(100, 25);
            this.partNumberTextBox.TabIndex = 6;
            this.partNumberTextBox.Text = "";
            this.partNumberTextBox.TextChanged += new System.EventHandler(this.partNumberTextBox_TextChanged);
            // 
            // partNumberLabel
            // 
            this.partNumberLabel.AutoSize = true;
            this.partNumberLabel.Location = new System.Drawing.Point(16, 93);
            this.partNumberLabel.Name = "partNumberLabel";
            this.partNumberLabel.Size = new System.Drawing.Size(66, 13);
            this.partNumberLabel.TabIndex = 5;
            this.partNumberLabel.Text = "Part Number";
            // 
            // expressRadioButton
            // 
            this.expressRadioButton.AutoSize = true;
            this.expressRadioButton.Location = new System.Drawing.Point(19, 19);
            this.expressRadioButton.Name = "expressRadioButton";
            this.expressRadioButton.Size = new System.Drawing.Size(62, 17);
            this.expressRadioButton.TabIndex = 6;
            this.expressRadioButton.TabStop = true;
            this.expressRadioButton.Text = "Express";
            this.expressRadioButton.UseVisualStyleBackColor = true;
            this.expressRadioButton.CheckedChanged += new System.EventHandler(this.expressRadioButton_CheckedChanged);
            // 
            // groundRadioButton
            // 
            this.groundRadioButton.AutoSize = true;
            this.groundRadioButton.Location = new System.Drawing.Point(19, 42);
            this.groundRadioButton.Name = "groundRadioButton";
            this.groundRadioButton.Size = new System.Drawing.Size(60, 17);
            this.groundRadioButton.TabIndex = 7;
            this.groundRadioButton.TabStop = true;
            this.groundRadioButton.Text = "Ground";
            this.groundRadioButton.UseVisualStyleBackColor = true;
            this.groundRadioButton.CheckedChanged += new System.EventHandler(this.groundRadioButton_CheckedChanged);
            // 
            // shippingGroupBox
            // 
            this.shippingGroupBox.Controls.Add(this.groundRadioButton);
            this.shippingGroupBox.Controls.Add(this.expressRadioButton);
            this.shippingGroupBox.Location = new System.Drawing.Point(29, 146);
            this.shippingGroupBox.Name = "shippingGroupBox";
            this.shippingGroupBox.Size = new System.Drawing.Size(107, 74);
            this.shippingGroupBox.TabIndex = 8;
            this.shippingGroupBox.TabStop = false;
            this.shippingGroupBox.Text = "&Shipping";
            this.toolTip1.SetToolTip(this.shippingGroupBox, "Select shipping option");
            // 
            // paymentTypeGroupBox
            // 
            this.paymentTypeGroupBox.Controls.Add(this.moneyOrderRadioButton);
            this.paymentTypeGroupBox.Controls.Add(this.codRadioButton);
            this.paymentTypeGroupBox.Controls.Add(this.chargeRadioButton);
            this.paymentTypeGroupBox.Location = new System.Drawing.Point(175, 146);
            this.paymentTypeGroupBox.Name = "paymentTypeGroupBox";
            this.paymentTypeGroupBox.Size = new System.Drawing.Size(140, 87);
            this.paymentTypeGroupBox.TabIndex = 9;
            this.paymentTypeGroupBox.TabStop = false;
            this.paymentTypeGroupBox.Text = "&Payment Type";
            this.toolTip1.SetToolTip(this.paymentTypeGroupBox, "Select payment type");
            // 
            // moneyOrderRadioButton
            // 
            this.moneyOrderRadioButton.AutoSize = true;
            this.moneyOrderRadioButton.Location = new System.Drawing.Point(19, 64);
            this.moneyOrderRadioButton.Name = "moneyOrderRadioButton";
            this.moneyOrderRadioButton.Size = new System.Drawing.Size(86, 17);
            this.moneyOrderRadioButton.TabIndex = 8;
            this.moneyOrderRadioButton.TabStop = true;
            this.moneyOrderRadioButton.Text = "Money Order";
            this.moneyOrderRadioButton.UseVisualStyleBackColor = true;
            this.moneyOrderRadioButton.CheckedChanged += new System.EventHandler(this.moneyOrderRadioButton_CheckedChanged);
            // 
            // codRadioButton
            // 
            this.codRadioButton.AutoSize = true;
            this.codRadioButton.Location = new System.Drawing.Point(19, 42);
            this.codRadioButton.Name = "codRadioButton";
            this.codRadioButton.Size = new System.Drawing.Size(48, 17);
            this.codRadioButton.TabIndex = 7;
            this.codRadioButton.TabStop = true;
            this.codRadioButton.Text = "COD";
            this.codRadioButton.UseVisualStyleBackColor = true;
            this.codRadioButton.CheckedChanged += new System.EventHandler(this.codRadioButton_CheckedChanged);
            // 
            // chargeRadioButton
            // 
            this.chargeRadioButton.AutoSize = true;
            this.chargeRadioButton.Location = new System.Drawing.Point(19, 19);
            this.chargeRadioButton.Name = "chargeRadioButton";
            this.chargeRadioButton.Size = new System.Drawing.Size(59, 17);
            this.chargeRadioButton.TabIndex = 6;
            this.chargeRadioButton.TabStop = true;
            this.chargeRadioButton.Text = "Charge";
            this.chargeRadioButton.UseVisualStyleBackColor = true;
            this.chargeRadioButton.CheckedChanged += new System.EventHandler(this.chargeRadioButton_CheckedChanged);
            // 
            // newCustomerCheckBox
            // 
            this.newCustomerCheckBox.AutoSize = true;
            this.newCustomerCheckBox.Location = new System.Drawing.Point(29, 241);
            this.newCustomerCheckBox.Name = "newCustomerCheckBox";
            this.newCustomerCheckBox.Size = new System.Drawing.Size(95, 17);
            this.newCustomerCheckBox.TabIndex = 10;
            this.newCustomerCheckBox.Text = "&New Customer";
            this.toolTip1.SetToolTip(this.newCustomerCheckBox, "Select if new customer");
            this.newCustomerCheckBox.UseVisualStyleBackColor = true;
            this.newCustomerCheckBox.VisibleChanged += new System.EventHandler(this.newCustomerLabel_Click);
            this.newCustomerCheckBox.CheckStateChanged += new System.EventHandler(this.newCustomerLabel_Click);
            this.newCustomerCheckBox.CheckedChanged += new System.EventHandler(this.newCustomerLabel_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(29, 427);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(80, 37);
            this.calculateButton.TabIndex = 11;
            this.calculateButton.Text = "&Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearButton.Location = new System.Drawing.Point(122, 427);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(80, 37);
            this.clearButton.TabIndex = 12;
            this.clearButton.Text = "Clea&r";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(221, 427);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(80, 37);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // orderSummaryGroupBox
            // 
            this.orderSummaryGroupBox.Controls.Add(this.newCustomerLabel);
            this.orderSummaryGroupBox.Controls.Add(this.partTextBox);
            this.orderSummaryGroupBox.Controls.Add(this.partLabel);
            this.orderSummaryGroupBox.Controls.Add(this.paymentTextBox);
            this.orderSummaryGroupBox.Controls.Add(this.paymentTypeLabel);
            this.orderSummaryGroupBox.Controls.Add(this.shippingTextBox);
            this.orderSummaryGroupBox.Controls.Add(this.totalCostTextBox);
            this.orderSummaryGroupBox.Controls.Add(this.shippingtypeLabel);
            this.orderSummaryGroupBox.Controls.Add(this.totalCostLabel);
            this.orderSummaryGroupBox.Location = new System.Drawing.Point(29, 286);
            this.orderSummaryGroupBox.Name = "orderSummaryGroupBox";
            this.orderSummaryGroupBox.Size = new System.Drawing.Size(405, 127);
            this.orderSummaryGroupBox.TabIndex = 6;
            this.orderSummaryGroupBox.TabStop = false;
            this.orderSummaryGroupBox.Text = "Order Summary";
            this.toolTip1.SetToolTip(this.orderSummaryGroupBox, "Order summary");
            // 
            // newCustomerLabel
            // 
            this.newCustomerLabel.AutoSize = true;
            this.newCustomerLabel.Location = new System.Drawing.Point(9, 23);
            this.newCustomerLabel.Name = "newCustomerLabel";
            this.newCustomerLabel.Size = new System.Drawing.Size(76, 13);
            this.newCustomerLabel.TabIndex = 9;
            this.newCustomerLabel.Text = "New Customer";
            this.newCustomerLabel.VisibleChanged += new System.EventHandler(this.newCustomerLabel_Click);
            this.newCustomerLabel.Click += new System.EventHandler(this.newCustomerLabel_Click);
            // 
            // partTextBox
            // 
            this.partTextBox.Enabled = false;
            this.partTextBox.Location = new System.Drawing.Point(88, 83);
            this.partTextBox.Name = "partTextBox";
            this.partTextBox.Size = new System.Drawing.Size(100, 25);
            this.partTextBox.TabIndex = 8;
            this.partTextBox.Text = "";
            // 
            // partLabel
            // 
            this.partLabel.AutoSize = true;
            this.partLabel.Location = new System.Drawing.Point(9, 86);
            this.partLabel.Name = "partLabel";
            this.partLabel.Size = new System.Drawing.Size(66, 13);
            this.partLabel.TabIndex = 7;
            this.partLabel.Text = "Part Number";
            // 
            // paymentTextBox
            // 
            this.paymentTextBox.Enabled = false;
            this.paymentTextBox.Location = new System.Drawing.Point(276, 49);
            this.paymentTextBox.Name = "paymentTextBox";
            this.paymentTextBox.Size = new System.Drawing.Size(100, 25);
            this.paymentTextBox.TabIndex = 6;
            this.paymentTextBox.Text = "";
            // 
            // paymentTypeLabel
            // 
            this.paymentTypeLabel.AutoSize = true;
            this.paymentTypeLabel.Location = new System.Drawing.Point(197, 52);
            this.paymentTypeLabel.Name = "paymentTypeLabel";
            this.paymentTypeLabel.Size = new System.Drawing.Size(75, 13);
            this.paymentTypeLabel.TabIndex = 5;
            this.paymentTypeLabel.Text = "Payment Type";
            // 
            // shippingTextBox
            // 
            this.shippingTextBox.Enabled = false;
            this.shippingTextBox.Location = new System.Drawing.Point(88, 52);
            this.shippingTextBox.Name = "shippingTextBox";
            this.shippingTextBox.Size = new System.Drawing.Size(100, 25);
            this.shippingTextBox.TabIndex = 4;
            this.shippingTextBox.Text = "";
            // 
            // totalCostTextBox
            // 
            this.totalCostTextBox.Enabled = false;
            this.totalCostTextBox.Location = new System.Drawing.Point(276, 83);
            this.totalCostTextBox.Name = "totalCostTextBox";
            this.totalCostTextBox.Size = new System.Drawing.Size(100, 25);
            this.totalCostTextBox.TabIndex = 3;
            this.totalCostTextBox.Text = "";
            // 
            // shippingtypeLabel
            // 
            this.shippingtypeLabel.AutoSize = true;
            this.shippingtypeLabel.Location = new System.Drawing.Point(9, 52);
            this.shippingtypeLabel.Name = "shippingtypeLabel";
            this.shippingtypeLabel.Size = new System.Drawing.Size(48, 13);
            this.shippingtypeLabel.TabIndex = 2;
            this.shippingtypeLabel.Text = "Shipping";
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Location = new System.Drawing.Point(215, 86);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(55, 13);
            this.totalCostLabel.TabIndex = 1;
            this.totalCostLabel.Text = "Total Cost";
            // 
            // BTunbutrProject1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearButton;
            this.ClientSize = new System.Drawing.Size(463, 476);
            this.Controls.Add(this.orderSummaryGroupBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.newCustomerCheckBox);
            this.Controls.Add(this.paymentTypeGroupBox);
            this.Controls.Add(this.shippingGroupBox);
            this.Controls.Add(this.orderInfoGroupBox);
            this.Controls.Add(this.pictureBox1);
            this.Name = "BTunbutrProject1";
            this.Text = "Custom Supplies Mail Order";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.orderInfoGroupBox.ResumeLayout(false);
            this.orderInfoGroupBox.PerformLayout();
            this.shippingGroupBox.ResumeLayout(false);
            this.shippingGroupBox.PerformLayout();
            this.paymentTypeGroupBox.ResumeLayout(false);
            this.paymentTypeGroupBox.PerformLayout();
            this.orderSummaryGroupBox.ResumeLayout(false);
            this.orderSummaryGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label costLabel;
        private System.Windows.Forms.Label quantityLabel;
        private System.Windows.Forms.RichTextBox costTextBox;
        private System.Windows.Forms.RichTextBox quantityTextBox;
        private System.Windows.Forms.GroupBox orderInfoGroupBox;
        private System.Windows.Forms.RadioButton expressRadioButton;
        private System.Windows.Forms.RadioButton groundRadioButton;
        private System.Windows.Forms.GroupBox shippingGroupBox;
        private System.Windows.Forms.GroupBox paymentTypeGroupBox;
        private System.Windows.Forms.RadioButton codRadioButton;
        private System.Windows.Forms.RadioButton chargeRadioButton;
        private System.Windows.Forms.RadioButton moneyOrderRadioButton;
        private System.Windows.Forms.CheckBox newCustomerCheckBox;
        private System.Windows.Forms.GroupBox orderSummaryGroupBox;
        private System.Windows.Forms.RichTextBox shippingTextBox;
        private System.Windows.Forms.RichTextBox totalCostTextBox;
        private System.Windows.Forms.Label shippingtypeLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.RichTextBox partNumberTextBox;
        private System.Windows.Forms.Label partNumberLabel;
        private System.Windows.Forms.RichTextBox paymentTextBox;
        private System.Windows.Forms.Label paymentTypeLabel;
        private System.Windows.Forms.RichTextBox partTextBox;
        private System.Windows.Forms.Label partLabel;
        private System.Windows.Forms.Label newCustomerLabel;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

