﻿/*
* Project: BTunbutrProject1
* Programmer: Bryant Tunbutr
* Date: September 19 2012
* Description: This project summarizes, calculates, and displays the charges for shipping a package.
* I certify that the code below is my own work.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication7
{
    public partial class BTunbutrProject1 : Form
    {
        public BTunbutrProject1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void costLabel_Click(object sender, EventArgs e)
        {

        }

        private void quantityLabel_Click(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Select the shipping options by using radio buttons.
        private void expressRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            shippingTextBox.Text = "Express";
        }

        private void groundRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            shippingTextBox.Text = "Ground";
        }

        // Select the payment options by using radio buttons.
        private void chargeRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            paymentTextBox.Text = "Charge";
        }

        private void codRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            paymentTextBox.Text = "COD";
        }

        private void moneyOrderRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            paymentTextBox.Text = "Money Order";
        }

        private void partNumberTextBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        /* Select if new customer. This label only appears in 
        the order summary if the checkbox is clicked.
         */
        private void newCustomerLabel_Click(object sender, EventArgs e)
        {
            newCustomerLabel.Visible = newCustomerCheckBox.Checked;
        }

        // Clicking the calculate button does calculations and displays the order summary.
        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Display the part number in the order summary.
            partTextBox.Text = partNumberTextBox.Text;

            // Calculate the total amount due.
            // Declare the variables.
            int quantityInt;
            decimal priceDec, extPriceDec;
            try
            {
                // Convert input values to numeric and assign to variables.
                quantityInt = int.Parse(quantityTextBox.Text);
                priceDec = decimal.Parse(costTextBox.Text);
                // Calculate values.
                extPriceDec = quantityInt * priceDec;

                //Display the results
                totalCostTextBox.Text = extPriceDec.ToString("C");

            }
            // To catch bad input.
            catch
            {
                MessageBox.Show("Bad input");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the text boxes.
            costTextBox.Text = "";
            quantityTextBox.Text = "";
            partNumberTextBox.Text = "";
            shippingTextBox.Text = "";
            paymentTextBox.Text = "";
            partTextBox.Text = "";
            totalCostTextBox.Text = "";
         
            costTextBox.Focus();

        }

    }
}
