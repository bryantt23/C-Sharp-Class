﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Look up values from text boxes.
        // Declare module-level variables.
        decimal[,] rateDecimal = new decimal[,] {{1M, 1.5M, 1.65M, 1.85M},
                                                {1.58M, 2M, 2.4M, 3.05M},
                                                {1.71M, 2.52M, 3.1M, 4M},
                                                {2.04M, 3.12M, 4M, 5.01M},
                                                {2.52M, 3.75M, 5.1M, 7.25M}};
        int[] weightInteger = new int[] { 1, 3, 5, 10 };
        string[] zoneString = new string[] { "A", "B", "C", "D" };


        private void lookUpButton_Click(object sender, EventArgs e)
        {

        }
    }
}
